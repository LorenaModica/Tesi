# Unofficial Beamer theme UniPi

Very opinionated beamer theme for University of Pisa. Made by a student for his thesis dissertation. Modified from [these slides](https://github.com/GaspareG/TesiDiscussione).

Colors taken from the [University's website](https://www.di.unipi.it).

Missing features:
- [ ] Math related environments
    - [ ] Equations
	- [ ] Theorems
	- [ ] Definitions
	- [ ] Proofs
- [ ] Add here

![image](https://user-images.githubusercontent.com/25388498/192098928-a881281e-1c49-4bba-930a-d43e3de2f617.png)

![image](https://user-images.githubusercontent.com/25388498/192098954-5e3cdfe2-1e65-4204-b514-43252461c144.png)

![image](https://user-images.githubusercontent.com/25388498/192098958-eb2c8ff7-4cbd-4664-9c61-61f18a725b1d.png)
